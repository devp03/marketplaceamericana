</main>
<footer>
    © 2025 Marketplace Universitario - Desarrollado por el grupo 3 |
    <a href="https://unimarketua.blogspot.com/2025/05/un-marketplace-universitario.html">Contáctenos</a>
  </footer>
</body>
</html>
